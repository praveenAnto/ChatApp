﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace ChatApp
{
    public class HomeViewModel : ViewModelBase
    {

        ObservableCollection<User> collection;

        ObservableCollection<Message> _recentChat;

        public ObservableCollection<User> Collection
        {
            get
            { 
                return collection; 
            }
            set
            {
                collection = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Message> RecentChat
        {
            get { return _recentChat; }
            set
            {
                _recentChat = value;
                OnPropertyChanged();
            }
        }

        public HomeViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
           Collection = new ObservableCollection<User>(MessageService.Instance.GetUsers());
           RecentChat = new ObservableCollection<Message>(MessageService.Instance.GetChats());
        }
    }
}
