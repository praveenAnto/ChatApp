﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp
{
    public class Message
    {
        public User Sender { get; set; }
        public string Text { get; set; }
        public string Time { get; set; }
    }
}
