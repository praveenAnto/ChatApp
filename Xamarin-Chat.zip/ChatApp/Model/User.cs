﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace ChatApp
{
    public class User
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public Color Color { get; set; }
    }
}
